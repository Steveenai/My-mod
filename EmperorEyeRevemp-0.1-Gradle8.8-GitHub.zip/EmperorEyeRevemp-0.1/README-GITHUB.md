# Emperor Eye Revemp — GitHub build

## Build depuis Android

Aucune installation de Gradle ou de Termux n'est nécessaire sur le téléphone.

1. Créer un dépôt GitHub.
2. Importer le contenu de ce dossier.
3. Ouvrir l'onglet **Actions**.
4. Lancer **Build Emperor Eye Revemp** avec **Run workflow**.
5. Après la réussite, ouvrir le run et récupérer l'artefact `emperor-eye-revemp`.

Le workflow utilise **Java 17** et **Gradle 8.8** directement sur GitHub Actions.

## À propos du Gradle Wrapper

Le dossier `gradle/wrapper` est présent pour préparer le projet, mais cette version du workflow utilise volontairement `gradle/actions/setup-gradle` + `gradle build`. Cela évite de dépendre d'un `gradle-wrapper.jar` absent du ZIP.
