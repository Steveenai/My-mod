# Emperor Eye Revemp — Forge 1.20.1

Projet ambitieux basé sur les fichiers de référence Emperor Eye 1.0.0, avec Photon 1.1.17 et Player Animation Lib.

## Objectif
- Œil gauche orange / œil droit jaune
- Ancrage précis aux yeux
- Trails et particules Photon
- Aura dynamique
- Modes Awakened / Overdrive / Emperor
- Capacités extensibles
- Animation « Humilié »
- HUD et effets de caméra prévus

## Version 0.1
La base contient déjà l'architecture client et un premier VFX léger. Les effets Photon complexes seront branchés après validation du premier lancement.

## Android / GitHub
Le dossier `libs/` contient les deux dépendances fournies par l'utilisateur. Le projet est conçu pour être compilé avec GitHub Actions.

⚠️ Le build complet n'a pas été exécuté dans cet environnement : les dépendances ForgeGradle sont téléchargées par Gradle lors du build.

## Build GitHub Actions

Le workflow `.github/workflows/build.yml` utilise Java 17 et Gradle 8.8. Aucun Gradle/Termux n'est nécessaire sur Android.
