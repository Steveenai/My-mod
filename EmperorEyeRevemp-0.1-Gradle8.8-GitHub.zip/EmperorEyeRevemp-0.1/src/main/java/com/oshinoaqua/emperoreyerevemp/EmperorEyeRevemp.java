package com.oshinoaqua.emperoreyerevemp;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(EmperorEyeRevemp.MOD_ID)
public final class EmperorEyeRevemp {
    public static final String MOD_ID = "emperoreyerevemp";
    public EmperorEyeRevemp() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
    }
}
