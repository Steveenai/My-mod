package com.oshinoaqua.emperoreyerevemp.client;

import com.oshinoaqua.emperoreyerevemp.client.fx.EyeVfxController;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid="emperoreyerevemp", value=Dist.CLIENT)
public final class ClientEvents {
    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        ClientEyeState.tick();
        EyeVfxController.tick();
    }
}
