package com.oshinoaqua.emperoreyerevemp.client;

import com.oshinoaqua.emperoreyerevemp.common.EyeMode;
import net.minecraft.client.Minecraft;

public final class ClientEyeState {
    private static EyeMode mode = EyeMode.AWAKENED;
    private static float intensity = 1.0f;
    private static float pulse;
    public static void tick() {
        if (Minecraft.getInstance().level == null) return;
        pulse += 0.08f;
        if (pulse > 1000f) pulse = 0f;
    }
    public static EyeMode mode() { return mode; }
    public static float intensity() { return intensity; }
    public static float pulse() { return pulse; }
    public static void setMode(EyeMode m) { mode = m; intensity = m == EyeMode.OFF ? 0f : 1f; }
    private ClientEyeState() {}
}
