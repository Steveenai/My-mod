package com.oshinoaqua.emperoreyerevemp.client.eye;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

public final class EyeAnchor {
    private EyeAnchor() {}
    public static Vec3 position(LivingEntity entity, float partialTick, boolean rightEye) {
        Vec3 center = entity.getEyePosition(partialTick);
        Vec3 forward = entity.getViewVector(partialTick).normalize();
        Vec3 right = new Vec3(0, 1, 0).cross(forward).normalize();
        // Socket spacing is intentionally conservative; the renderer can tune it later.
        double side = rightEye ? 0.055 : -0.055;
        return center.add(right.scale(side)).add(forward.scale(0.018));
    }
}
