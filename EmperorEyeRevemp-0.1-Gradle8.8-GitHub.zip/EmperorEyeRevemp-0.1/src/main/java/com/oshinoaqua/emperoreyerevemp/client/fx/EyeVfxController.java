package com.oshinoaqua.emperoreyerevemp.client.fx;

import com.oshinoaqua.emperoreyerevemp.client.ClientEyeState;
import com.oshinoaqua.emperoreyerevemp.client.eye.EyeAnchor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

public final class EyeVfxController {
    private EyeVfxController() {}
    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || ClientEyeState.intensity() <= 0f) return;
        ClientLevel level = mc.level;
        Player p = mc.player;
        float t = ClientEyeState.pulse();
        spawnEye(level, p, false, new Vector3f(1.0f, 0.36f, 0.04f), t);
        spawnEye(level, p, true, new Vector3f(1.0f, 0.84f, 0.08f), t + 1.7f);
    }
    private static void spawnEye(ClientLevel level, Player p, boolean right, Vector3f color, float seed) {
        Vec3 pos = EyeAnchor.position(p, 1f, right);
        double drift = Math.sin(seed * 1.7) * 0.012;
        DustParticleOptions dust = new DustParticleOptions(color, 0.65f);
        level.addParticle(dust, pos.x + drift, pos.y, pos.z + drift);
    }
}
