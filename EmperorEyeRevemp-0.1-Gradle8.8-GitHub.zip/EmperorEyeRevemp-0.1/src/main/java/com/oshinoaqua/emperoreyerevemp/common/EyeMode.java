package com.oshinoaqua.emperoreyerevemp.common;

public enum EyeMode {
    OFF(0x000000, 0x000000),
    AWAKENED(0xFF7A16, 0xFFD83D),
    OVERDRIVE(0xFF4A00, 0xFFF200),
    EMPEROR(0xFF9A22, 0xFFF56A);
    public final int orange;
    public final int yellow;
    EyeMode(int orange, int yellow) { this.orange = orange; this.yellow = yellow; }
}
