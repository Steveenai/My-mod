# Emperor Eye Revemp — VFX v0.2

Cette version ajoute un VFX client continu pour les yeux.

## VFX inclus
- Trail orange très fin depuis l'œil gauche.
- Trail jaune très fin depuis l'œil droit.
- Interpolation Catmull-Rom pour éviter l'effet « particules séparées ».
- Double passe de rendu pour donner un cœur lumineux + halo.
- Petits éclairs autour des yeux quand le pouvoir est actif.
- Aura rouge en rubans autour du corps.
- L'aura se contracte progressivement quand une autre entité vivante s'approche.

## Fichiers principaux
- `client/fx/EyeVfxController.java` : génération et rendu du VFX.
- `client/ClientEvents.java` : tick + rendu dans le niveau.
- `client/eye/EyeAnchor.java` : position des deux yeux.

## Important
Le VFX est généré côté client et ne dépend pas d'un spam de particules. Photon 1.20.1-1.1.17 reste inclus dans `libs/` pour les futurs effets authored dans l'éditeur Photon.
