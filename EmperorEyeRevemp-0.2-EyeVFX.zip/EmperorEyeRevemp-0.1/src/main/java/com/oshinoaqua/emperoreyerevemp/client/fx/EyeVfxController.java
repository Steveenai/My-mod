package com.oshinoaqua.emperoreyerevemp.client.fx;

import com.oshinoaqua.emperoreyerevemp.client.ClientEyeState;
import com.oshinoaqua.emperoreyerevemp.client.eye.EyeAnchor;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Emperor Eye VFX: two continuous eye trails, eye lightning and a red compression aura.
 * The geometry is generated client-side so the effect stays smooth instead of becoming
 * a cloud of discrete particles. Photon remains available for authored FX assets.
 */
public final class EyeVfxController {
    private static final int TRAIL_POINTS = 34;
    private static final Deque<Vec3> ORANGE = new ArrayDeque<>();
    private static final Deque<Vec3> YELLOW = new ArrayDeque<>();

    private EyeVfxController() {}

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || ClientEyeState.intensity() <= 0f) {
            ORANGE.clear();
            YELLOW.clear();
            return;
        }

        Player p = mc.player;
        push(ORANGE, EyeAnchor.position(p, 1f, false));
        push(YELLOW, EyeAnchor.position(p, 1f, true));
    }

    private static void push(Deque<Vec3> trail, Vec3 pos) {
        trail.addLast(pos);
        while (trail.size() > TRAIL_POINTS) trail.removeFirst();
    }

    public static void render(PoseStack poseStack, Camera camera, float partialTick) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || ClientEyeState.intensity() <= 0f) return;
        if (ORANGE.size() < 2 || YELLOW.size() < 2) return;

        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer lines = buffers.getBuffer(RenderType.lines());
        Vec3 cam = camera.getPosition();

        poseStack.pushPose();
        poseStack.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f matrix = poseStack.last().pose();
        Matrix3f normal = poseStack.last().normal();

        // Three passes give the thin trail a bright core + soft visual halo.
        renderTrail(lines, matrix, normal, new ArrayList<>(ORANGE), 1.0f, 0.36f, 0.03f);
        renderTrail(lines, matrix, normal, new ArrayList<>(ORANGE), 1.0f, 0.20f, 0.01f);
        renderTrail(lines, matrix, normal, new ArrayList<>(YELLOW), 1.0f, 0.84f, 0.08f);
        renderTrail(lines, matrix, normal, new ArrayList<>(YELLOW), 1.0f, 0.58f, 0.02f);

        renderEyeLightning(lines, matrix, normal, mc.player, partialTick);
        renderRedAura(lines, matrix, normal, mc.level, mc.player, partialTick);

        poseStack.popPose();
        buffers.endBatch(RenderType.lines());
    }

    private static void renderTrail(VertexConsumer out, Matrix4f matrix, Matrix3f normal,
                                    List<Vec3> raw, float r, float g, float b) {
        if (raw.size() < 2) return;
        List<Vec3> smooth = smooth(raw, 3);
        for (int i = 0; i < smooth.size() - 1; i++) {
            Vec3 a = smooth.get(i);
            Vec3 c = smooth.get(i + 1);
            float t = i / (float) Math.max(1, smooth.size() - 2);
            float alpha = 0.12f + 0.88f * t;
            // Bright head, fading tail. A second pass above creates the glow impression.
            line(out, matrix, normal, a, c, r, g, b, alpha);
        }
    }

    private static List<Vec3> smooth(List<Vec3> p, int subdivisions) {
        if (p.size() < 3) return p;
        List<Vec3> result = new ArrayList<>((p.size() - 1) * subdivisions + 1);
        for (int i = 0; i < p.size() - 1; i++) {
            Vec3 p0 = p.get(Math.max(0, i - 1));
            Vec3 p1 = p.get(i);
            Vec3 p2 = p.get(i + 1);
            Vec3 p3 = p.get(Math.min(p.size() - 1, i + 2));
            for (int s = 0; s < subdivisions; s++) {
                double t = s / (double) subdivisions;
                result.add(catmull(p0, p1, p2, p3, t));
            }
        }
        result.add(p.get(p.size() - 1));
        return result;
    }

    private static Vec3 catmull(Vec3 p0, Vec3 p1, Vec3 p2, Vec3 p3, double t) {
        double t2 = t * t;
        double t3 = t2 * t;
        return new Vec3(
                0.5 * ((2*p1.x) + (-p0.x+p2.x)*t + (2*p0.x-5*p1.x+4*p2.x-p3.x)*t2 + (-p0.x+3*p1.x-3*p2.x+p3.x)*t3),
                0.5 * ((2*p1.y) + (-p0.y+p2.y)*t + (2*p0.y-5*p1.y+4*p2.y-p3.y)*t2 + (-p0.y+3*p1.y-3*p2.y+p3.y)*t3),
                0.5 * ((2*p1.z) + (-p0.z+p2.z)*t + (2*p0.z-5*p1.z+4*p2.z-p3.z)*t2 + (-p0.z+3*p1.z-3*p2.z+p3.z)*t3)
        );
    }

    private static void renderEyeLightning(VertexConsumer out, Matrix4f matrix, Matrix3f normal,
                                           Player p, float partialTick) {
        float time = ClientEyeState.pulse();
        renderLightningBurst(out, matrix, normal, EyeAnchor.position(p, partialTick, false), time, 0.9f, 0.28f, 0.03f, 0);
        renderLightningBurst(out, matrix, normal, EyeAnchor.position(p, partialTick, true), time + 1.7f, 1.0f, 0.75f, 0.03f, 1);
    }

    private static void renderLightningBurst(VertexConsumer out, Matrix4f matrix, Matrix3f normal,
                                              Vec3 origin, float time, float r, float g, float b, int seed) {
        double phase = time * 2.8 + seed * 2.1;
        for (int arm = 0; arm < 3; arm++) {
            double a = phase + arm * (Math.PI * 2.0 / 3.0);
            double length = 0.09 + 0.07 * (0.5 + 0.5 * Math.sin(phase * 1.7 + arm));
            Vec3 prev = origin;
            for (int s = 1; s <= 4; s++) {
                double d = length * s / 4.0;
                double wobble = Math.sin(phase * 3.0 + s * 4.1 + arm) * 0.025;
                Vec3 next = origin.add(Math.cos(a) * d, Math.sin(a * 1.37) * d + wobble, Math.sin(a) * d);
                line(out, matrix, normal, prev, next, r, g, b, 0.55f);
                prev = next;
            }
        }
    }

    private static void renderRedAura(VertexConsumer out, Matrix4f matrix, Matrix3f normal,
                                      ClientLevel level, Player player, float partialTick) {
        // The aura exists while the eye state is active. It contracts when another living
        // entity approaches, giving the "shadow pulled back into the body" look.
        double nearest = 8.0;
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(8.0), e -> e != player && e.isAlive())) {
            nearest = Math.min(nearest, Math.sqrt(entity.distanceToSqr(player)));
        }
        double approach = clamp((8.0 - nearest) / 6.5, 0.0, 1.0);
        double radius = 1.85 - 1.20 * approach;
        double height = 2.35 - 0.45 * approach;
        float intensity = (float) (0.28 + 0.45 * approach);
        double phase = ClientEyeState.pulse() * 0.65;

        for (int strand = 0; strand < 4; strand++) {
            List<Vec3> pts = new ArrayList<>();
            for (int i = 0; i <= 18; i++) {
                double t = i / 18.0;
                double angle = phase + strand * Math.PI / 2.0 + t * Math.PI * 2.2;
                double rr = radius * (0.78 + 0.22 * Math.sin(t * Math.PI));
                double y = player.getY() + 0.10 + t * height;
                pts.add(new Vec3(player.getX() + Math.cos(angle) * rr, y,
                        player.getZ() + Math.sin(angle) * rr));
            }
            List<Vec3> smooth = smooth(pts, 2);
            for (int i = 0; i < smooth.size() - 1; i++) {
                float fade = (float) (0.35 + 0.65 * Math.sin(Math.PI * i / (smooth.size() - 1)));
                line(out, matrix, normal, smooth.get(i), smooth.get(i + 1), 0.95f, 0.02f, 0.015f, intensity * fade);
            }
        }
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    private static void line(VertexConsumer out, Matrix4f matrix, Matrix3f normal,
                             Vec3 a, Vec3 b, float r, float g, float bl, float alpha) {
        out.vertex(matrix, (float)a.x, (float)a.y, (float)a.z)
                .color((int)(r*255), (int)(g*255), (int)(bl*255), (int)(alpha*255))
                .normal(normal, 0, 1, 0).endVertex();
        out.vertex(matrix, (float)b.x, (float)b.y, (float)b.z)
                .color((int)(r*255), (int)(g*255), (int)(bl*255), (int)(alpha*255))
                .normal(normal, 0, 1, 0).endVertex();
    }
}
