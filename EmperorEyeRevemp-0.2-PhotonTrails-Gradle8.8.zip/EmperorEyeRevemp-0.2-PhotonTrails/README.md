# Emperor Eye Revemp 0.2.0

Forge 1.20.1 / Java 17 / Gradle 8.8.

## VFX
This version focuses on the visual direction shown in the reference:
- long luminous trails attached to the two eyes;
- multiple parallel strands;
- hotter white center;
- orange and yellow eye colors;
- trail length increases with player movement speed;
- small sparks around the eye sockets.

Keys:
- R: toggle the Emperor Eye effect.
- Y: cycle Orange -> Yellow -> Both.

Photon 1.1.17 and Player Animation Library are included in `libs/` for the next VFX/animation layers. The current trail renderer uses Forge/Minecraft particles so the base build remains easy to test; Photon-specific effects can be added after the first successful build.

## Build
Use Java 17 and Gradle 8.8.

GitHub Actions can install Gradle 8.8 directly. The project wrapper configuration also points to Gradle 8.8.
