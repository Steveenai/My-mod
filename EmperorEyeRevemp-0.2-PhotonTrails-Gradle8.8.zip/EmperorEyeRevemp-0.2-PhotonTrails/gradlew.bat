@echo off
rem Emperor Eye Revemp - Gradle 8.8 project
gradle %*
