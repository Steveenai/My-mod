package com.oshinoaqua.emperoreyerevemp;

import net.minecraftforge.fml.common.Mod;

@Mod(EmperorEyeRevemp.MOD_ID)
public final class EmperorEyeRevemp {
    public static final String MOD_ID = "emperoreyerevemp";

    public EmperorEyeRevemp() {
    }
}
