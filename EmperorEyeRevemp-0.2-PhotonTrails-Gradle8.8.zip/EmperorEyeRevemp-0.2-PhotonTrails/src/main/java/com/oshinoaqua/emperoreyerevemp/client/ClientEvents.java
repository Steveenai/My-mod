package com.oshinoaqua.emperoreyerevemp.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.oshinoaqua.emperoreyerevemp.client.fx.EyeVfxController;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = "emperoreyerevemp", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientEvents {
    private static final KeyMapping TOGGLE =
            new KeyMapping("key.emperoreyerevemp.toggle", KeyConflictContext.IN_GAME,
                    InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.emperoreyerevemp");

    private static final KeyMapping COLOR =
            new KeyMapping("key.emperoreyerevemp.color", KeyConflictContext.IN_GAME,
                    InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_Y, "key.categories.emperoreyerevemp");

    private ClientEvents() {}

    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        ClientEyeState.tick();

        while (TOGGLE.consumeClick()) {
            ClientEyeState.toggle();
        }

        while (COLOR.consumeClick()) {
            ClientEyeState.switchColor();
        }

        EyeVfxController.tick();
    }

    @Mod.EventBusSubscriber(modid = "emperoreyerevemp", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ModBus {
        @SubscribeEvent
        public static void registerKeys(RegisterKeyMappingsEvent event) {
            event.register(TOGGLE);
            event.register(COLOR);
        }
    }
}
