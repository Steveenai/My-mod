package com.oshinoaqua.emperoreyerevemp.client;

import com.oshinoaqua.emperoreyerevemp.common.EyeMode;
import net.minecraft.client.Minecraft;

public final class ClientEyeState {
    private static EyeMode mode = EyeMode.BOTH;
    private static float pulse;

    private ClientEyeState() {}

    public static void tick() {
        if (Minecraft.getInstance().level == null) return;
        pulse += 0.10f;
        if (pulse > 10000f) pulse = 0f;
    }

    public static EyeMode mode() {
        return mode;
    }

    public static float pulse() {
        return pulse;
    }

    public static void toggle() {
        mode = mode == EyeMode.OFF ? EyeMode.BOTH : EyeMode.OFF;
    }

    public static void switchColor() {
        mode = switch (mode) {
            case OFF -> EyeMode.ORANGE;
            case ORANGE -> EyeMode.YELLOW;
            case YELLOW -> EyeMode.BOTH;
            case BOTH -> EyeMode.ORANGE;
        };
    }
}
