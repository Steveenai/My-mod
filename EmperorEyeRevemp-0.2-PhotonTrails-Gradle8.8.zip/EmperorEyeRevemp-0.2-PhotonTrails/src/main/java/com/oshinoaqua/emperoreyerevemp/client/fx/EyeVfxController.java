package com.oshinoaqua.emperoreyerevemp.client.fx;

import com.oshinoaqua.emperoreyerevemp.client.ClientEyeState;
import com.oshinoaqua.emperoreyerevemp.client.eye.EyeAnchor;
import com.oshinoaqua.emperoreyerevemp.common.EyeMode;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

public final class EyeVfxController {
    private EyeVfxController() {}

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        EyeMode mode = ClientEyeState.mode();
        if (mode == EyeMode.OFF) return;

        Player player = mc.player;
        Vec3 velocity = player.getDeltaMovement();
        double speed = velocity.length();

        // The effect becomes visibly longer as the player moves faster.
        double trailLength = Math.min(3.8, 0.65 + speed * 8.0);
        float pulse = ClientEyeState.pulse();

        if (mode == EyeMode.ORANGE || mode == EyeMode.BOTH) {
            spawnTrail(mc.level, player, false, new Vector3f(1.0f, 0.22f, 0.015f), trailLength, pulse);
        }

        if (mode == EyeMode.YELLOW || mode == EyeMode.BOTH) {
            spawnTrail(mc.level, player, true, new Vector3f(1.0f, 0.82f, 0.03f), trailLength, pulse + 2.1f);
        }
    }

    private static void spawnTrail(
            ClientLevel level,
            Player player,
            boolean rightEye,
            Vector3f color,
            double trailLength,
            float seed
    ) {
        Vec3 start = EyeAnchor.position(player, 1.0f, rightEye);

        Vec3 velocity = player.getDeltaMovement();
        Vec3 direction;

        if (velocity.lengthSqr() > 0.0004) {
            direction = velocity.normalize().scale(-1.0);
        } else {
            direction = player.getViewVector(1.0f).normalize().scale(-0.32);
        }

        DustParticleOptions core = new DustParticleOptions(color, 0.72f);

        // Several parallel strands create the long luminous streak look.
        for (int strand = 0; strand < 3; strand++) {
            double side = (strand - 1) * 0.035;
            Vec3 offset = player.getViewVector(1.0f).cross(new Vec3(0, 1, 0)).normalize().scale(side);

            int points = 9 + (int)(trailLength * 3.0);
            for (int i = 1; i <= points; i++) {
                double progress = i / (double) points;
                double distance = progress * trailLength;
                double wave = Math.sin(seed * 1.4 + i * 0.85) * 0.018 * progress;

                Vec3 pos = start
                        .add(direction.scale(distance))
                        .add(offset)
                        .add(0, wave, 0);

                level.addParticle(
                        core,
                        pos.x,
                        pos.y,
                        pos.z,
                        0.0,
                        0.0,
                        0.0
                );

                // A sparse white core gives the streak a hotter center.
                if (i % 3 == 0 && strand == 1) {
                    level.addParticle(
                            ParticleTypes.END_ROD,
                            pos.x,
                            pos.y,
                            pos.z,
                            0.0,
                            0.0,
                            0.0
                    );
                }
            }
        }

        // Small sparks around the eye socket.
        for (int i = 0; i < 2; i++) {
            double a = seed * 0.7 + i * Math.PI;
            Vec3 spark = start.add(Math.cos(a) * 0.09, Math.sin(a) * 0.045, Math.sin(a) * 0.09);
            level.addParticle(core, spark.x, spark.y, spark.z, 0, 0, 0);
        }
    }
}
