package com.oshinoaqua.emperoreyerevemp.common;

public enum EyeMode {
    OFF,
    ORANGE,
    YELLOW,
    BOTH
}
