# KimetsuCraft Serpent Beta 5 — Forge 1.20.1

Cette version affine le serpent visuel :
- silhouette basée sur le dragon 3D de KimetsuCraft 0.3.0, mais légèrement amincie/allongée ;
- texture indigo/violette dédiée ;
- animation GeckoLib d'ondulation continue ;
- modèle rendu comme une vraie entité GeckoLib autour du joueur ;
- touches 1 et 2 pour les deux démonstrations visuelles ;
- première forme : impulsion verticale puis descente visuelle ;
- deuxième forme : rotation visuelle du serpent autour du joueur ;
- effets violets supplémentaires.

Dépendances placées dans `libs/` : KimetsuCraft 0.3.0, GeckoLib 4.8.4, Player Animator 1.0.2-rc1+1.20 et AAA Particles 1.4.15.

Cette bêta ne contient pas de mécanique de dégâts.
