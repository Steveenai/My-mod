package com.serpentaddon;

import com.serpentaddon.entity.SerpentEntities;
import com.serpentaddon.client.SerpentClient;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.eventbus.api.IEventBus;

@Mod(SerpentAddon.MODID)
public final class SerpentAddon {
    public static final String MODID="serpentaddon";
    public SerpentAddon(){
        IEventBus bus=FMLJavaModLoadingContext.get().getModEventBus();
        SerpentEntities.ENTITIES.register(bus);
        MinecraftForge.EVENT_BUS.register(this);
    }
}
