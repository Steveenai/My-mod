package com.serpentaddon.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.serpentaddon.entity.SerpentEntities;
import com.serpentaddon.entity.SerpentVisualEntity;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = "serpentaddon", value = net.minecraftforge.api.distmarker.Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class SerpentClient {
    private static KeyMapping FORM_ONE, FORM_TWO;
    private static int mode = 0, ticks = 0;

    @SubscribeEvent public static void registerKeys(RegisterKeyMappingsEvent e) {
        FORM_ONE = new KeyMapping("key.serpentaddon.form_one", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_1, "key.categories.serpentaddon");
        FORM_TWO = new KeyMapping("key.serpentaddon.form_two", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_2, "key.categories.serpentaddon");
        e.register(FORM_ONE); e.register(FORM_TWO);
    }
    @SubscribeEvent public static void registerRenderers(EntityRenderersEvent.RegisterRenderers e) { e.registerEntityRenderer(SerpentEntities.SERPENT_VISUAL.get(), SerpentRenderer::new); }
    @SubscribeEvent public static void onKey(InputEvent.Key e) {
        Minecraft mc=Minecraft.getInstance();
        if(mc.player==null || mc.screen!=null || e.getAction()!=GLFW.GLFW_PRESS) return;
        if(FORM_ONE!=null && e.getKey()==FORM_ONE.getKey().getValue()) start(1);
        if(FORM_TWO!=null && e.getKey()==FORM_TWO.getKey().getValue()) start(2);
    }
    private static void start(int form) {
        LocalPlayer p=Minecraft.getInstance().player; if(p==null) return;
        mode=form; ticks=form==1?34:42;
        SerpentVisualEntity s=new SerpentVisualEntity(SerpentEntities.SERPENT_VISUAL.get(),p.level());
        s.configure(p,ticks,form==1?0f:1.2f); p.level().addFreshEntity(s);
        if(form==1) p.setDeltaMovement(p.getDeltaMovement().x,0.82,p.getDeltaMovement().z);
    }
    @SubscribeEvent public static void clientTick(TickEvent.ClientTickEvent e) {
        if(e.phase!=TickEvent.Phase.END || ticks<=0) return;
        LocalPlayer p=Minecraft.getInstance().player; if(p==null) {ticks=0; return;}
        int age=ticks--; float t=1f-age/(mode==1?34f:42f);
        for(int i=0;i<7;i++) {
            double a=t*Math.PI*6+i*(Math.PI*2/7); double r=1.35+0.18*Math.sin(t*Math.PI);
            double x=p.getX()+Math.cos(a)*r, z=p.getZ()+Math.sin(a)*r, y=p.getY()+0.45+0.25*Math.sin(a*1.4);
            p.level().addParticle(new DustParticleOptions(new Vector3f(0.68f,0.08f,0.95f),1.15f),x,y,z,0,0.015,0);
        }
        if(mode==1 && age==18) p.setDeltaMovement(p.getDeltaMovement().x,-0.75,p.getDeltaMovement().z);
    }
}
