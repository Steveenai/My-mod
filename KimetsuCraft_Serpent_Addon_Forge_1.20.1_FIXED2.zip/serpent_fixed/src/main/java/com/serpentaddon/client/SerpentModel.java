package com.serpentaddon.client;

import com.serpentaddon.SerpentAddon;
import com.serpentaddon.entity.SerpentVisualEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoRenderer;

public class SerpentModel extends GeoModel<SerpentVisualEntity> {
    @Override public ResourceLocation getModelResource(SerpentVisualEntity animatable) { return new ResourceLocation(SerpentAddon.MODID, "geo/serpent_dragon.geo.json"); }
    @Override public ResourceLocation getTextureResource(SerpentVisualEntity animatable) { return new ResourceLocation(SerpentAddon.MODID, "textures/entity/serpent_dragon.png"); }
    @Override public ResourceLocation getAnimationResource(SerpentVisualEntity animatable) { return new ResourceLocation(SerpentAddon.MODID, "animations/serpent_dragon.animation.json"); }
}
