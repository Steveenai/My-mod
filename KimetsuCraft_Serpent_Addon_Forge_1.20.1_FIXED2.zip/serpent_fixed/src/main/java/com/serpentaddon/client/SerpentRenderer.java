package com.serpentaddon.client;

import com.serpentaddon.entity.SerpentVisualEntity;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

public class SerpentRenderer extends GeoEntityRenderer<SerpentVisualEntity> {
    public SerpentRenderer(EntityRendererProvider.Context context) {
        super(context, new SerpentModel());
        this.shadowRadius = 0.0f;
        this.withScale(0.72f);
    }
}
