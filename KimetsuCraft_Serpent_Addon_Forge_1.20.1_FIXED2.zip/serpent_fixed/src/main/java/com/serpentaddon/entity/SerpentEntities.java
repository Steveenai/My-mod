package com.serpentaddon.entity;

import com.serpentaddon.SerpentAddon;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class SerpentEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SerpentAddon.MODID);
    public static final RegistryObject<EntityType<SerpentVisualEntity>> SERPENT_VISUAL = ENTITIES.register("serpent_visual",
        () -> EntityType.Builder.<SerpentVisualEntity>of(SerpentVisualEntity::new, MobCategory.MISC)
            .sized(4.0f, 4.0f).clientTrackingRange(64).updateInterval(1).build(SerpentAddon.MODID + ":serpent_visual"));
    private SerpentEntities() {}
}
