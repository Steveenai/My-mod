package com.serpentaddon.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;
import net.minecraftforge.network.NetworkHooks;

public class SerpentVisualEntity extends Entity implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("serpent_dragon.idle");
    private int life;
    private int maxLife = 40;
    private int ownerId = -1;
    private float orbitAngle;

    public SerpentVisualEntity(EntityType<? extends SerpentVisualEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public void configure(Entity owner, int lifetime, float startAngle) {
        this.ownerId = owner.getId();
        this.maxLife = lifetime;
        this.life = lifetime;
        this.orbitAngle = startAngle;
        this.setPos(owner.getX(), owner.getY() + 0.7, owner.getZ());
    }

    @Override protected void defineSynchedData() {}
    @Override protected void readAdditionalSaveData(CompoundTag tag) { life = tag.getInt("Life"); maxLife = Math.max(1, tag.getInt("MaxLife")); ownerId = tag.getInt("OwnerId"); }
    @Override protected void addAdditionalSaveData(CompoundTag tag) { tag.putInt("Life", life); tag.putInt("MaxLife", maxLife); tag.putInt("OwnerId", ownerId); }

    @Override public void tick() {
        super.tick();
        if (level().isClientSide) {
            Entity owner = level().getEntity(ownerId);
            if (owner != null) {
                float progress = 1f - (life / (float)Math.max(1, maxLife));
                orbitAngle += 0.12f;
                double radius = 1.7 + 0.25 * Math.sin(progress * Math.PI);
                double x = owner.getX() + Math.cos(orbitAngle) * radius;
                double z = owner.getZ() + Math.sin(orbitAngle) * radius;
                double y = owner.getY() + 1.0 + 0.35 * Math.sin(orbitAngle * 1.6);
                setPos(x, y, z);
            }
        }
        if (--life <= 0) discard();
    }

    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "serpent_idle", state -> state.setAndContinue(IDLE)));
    }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
    @Override public double getTick(Object animatable) { return tickCount; }
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
}
