package com.serpentaddon;

import com.serpentaddon.entity.SerpentEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.eventbus.api.IEventBus;

@Mod(SerpentAddon.MODID)
public final class SerpentAddon {
    public static final String MODID="serpentaddon";
    public SerpentAddon(){
        IEventBus bus=FMLJavaModLoadingContext.get().getModEventBus();
        SerpentEntities.ENTITIES.register(bus);
        DistExecutor.safeRunWhenOn(Dist.CLIENT, () -> () -> com.serpentaddon.client.SerpentClient.init(bus));
    }
}
