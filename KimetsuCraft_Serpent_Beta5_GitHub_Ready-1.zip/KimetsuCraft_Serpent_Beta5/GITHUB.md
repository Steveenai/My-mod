# GitHub — compilation

Ce projet est un **addon** pour KimetsuCraft 0.3.0. Le fichier `kimetsucraft-0.3.0.jar` n'est volontairement PAS inclus.

1. Crée un dépôt GitHub vide.
2. Envoie le contenu de ce dossier.
3. Va dans **Actions** → **Build Serpent Addon**.
4. Clique **Run workflow**.
5. Une fois terminé, ouvre le workflow puis **Artifacts** → `serpent-addon`.

Le JAR obtenu est l'addon uniquement. Il doit être utilisé avec KimetsuCraft 0.3.0 installé dans Minecraft.
