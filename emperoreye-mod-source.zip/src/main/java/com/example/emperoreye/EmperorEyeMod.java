package com.example.emperoreye;

import com.example.emperoreye.registry.ModAttachments;
import com.example.emperoreye.registry.ModEntities;
import com.example.emperoreye.registry.ModItems;
import com.example.emperoreye.registry.ModPayloads;
import com.example.emperoreye.server.ServerEventHandler;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;

@Mod(EmperorEyeMod.MODID)
public class EmperorEyeMod {
    public static final String MODID = "emperoreye";

    public EmperorEyeMod(IEventBus modEventBus, ModContainer container) {
        ModItems.ITEMS.register(modEventBus);
        ModEntities.ENTITIES.register(modEventBus);
        ModAttachments.ATTACHMENT_TYPES.register(modEventBus);

        modEventBus.addListener(ModPayloads::register);

        NeoForge.EVENT_BUS.register(new ServerEventHandler());
    }
}
