package com.example.emperoreye.client;

import com.example.emperoreye.EmperorEyeMod;
import com.example.emperoreye.network.ControlVictimPayload;
import com.example.emperoreye.network.ToggleEmperorModePayload;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = EmperorEyeMod.MODID, value = Dist.CLIENT)
public class ClientSetup {

    // Etat local juste pour l'affichage de l'overlay (le vrai état de jeu vit côté serveur)
    public static boolean emperorModeClient = false;

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(KeyBindings.EMPEROR_MODE);
        event.register(KeyBindings.CONTROL_VICTIM);
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        // Z : bascule (une seule fois par appui)
        while (KeyBindings.EMPEROR_MODE.consumeClick()) {
            emperorModeClient = !emperorModeClient;
            PacketDistributor.sendToServer(new ToggleEmperorModePayload());
        }

        // R : maintenu -> on envoie l'état des touches de déplacement chaque tick
        if (KeyBindings.CONTROL_VICTIM.isDown()) {
            float forward = 0f;
            if (mc.options.keyUp.isDown()) forward += 1f;
            if (mc.options.keyDown.isDown()) forward -= 1f;

            float strafe = 0f;
            if (mc.options.keyLeft.isDown()) strafe += 1f;
            if (mc.options.keyRight.isDown()) strafe -= 1f;

            boolean jump = mc.options.keyJump.isDown();
            boolean attack = mc.options.keyAttack.isDown();
            boolean use = mc.options.keyUse.isDown();

            PacketDistributor.sendToServer(new ControlVictimPayload(forward, strafe, jump, attack, use));
        }
    }
}
