package com.example.emperoreye.client;

import com.example.emperoreye.EmperorEyeMod;
import net.minecraft.client.gui.GuiGraphics;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderGuiEvent;

@EventBusSubscriber(modid = EmperorEyeMod.MODID, value = Dist.CLIENT)
public class EmperorOverlay {

    private static final int RED_VIGNETTE = 0x33FF0000;

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        if (!ClientSetup.emperorModeClient) return;

        GuiGraphics graphics = event.getGuiGraphics();
        int w = graphics.guiWidth();
        int h = graphics.guiHeight();
        int thickness = 5;

        graphics.fill(0, 0, w, thickness, RED_VIGNETTE);
        graphics.fill(0, h - thickness, w, h, RED_VIGNETTE);
        graphics.fill(0, 0, thickness, h, RED_VIGNETTE);
        graphics.fill(w - thickness, 0, w, h, RED_VIGNETTE);
    }
}
