package com.example.emperoreye.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.neoforged.neoforge.client.settings.KeyConflictContext;

public class KeyBindings {
    public static final KeyMapping EMPEROR_MODE = new KeyMapping(
            "key.emperoreye.emperor_mode",
            KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM,
            InputConstants.KEY_Z,
            "key.categories.emperoreye"
    );

    public static final KeyMapping CONTROL_VICTIM = new KeyMapping(
            "key.emperoreye.control_victim",
            KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM,
            InputConstants.KEY_R,
            "key.categories.emperoreye"
    );
}
