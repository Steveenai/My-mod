package com.example.emperoreye.entity;

import com.example.emperoreye.registry.ModAttachments;
import com.example.emperoreye.util.PlayerPossessionState;
import com.example.emperoreye.util.PossessionState;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * Perle rouge à trajectoire courbe (homing) qui possède l'entité qu'elle touche.
 */
public class RedPearlEntity extends ThrowableItemProjectile {

    private int targetId = -1;
    private static final float TRAIL_COLOR_R = 1.0f;
    private static final float TRAIL_COLOR_G = 0.05f;
    private static final float TRAIL_COLOR_B = 0.05f;

    public RedPearlEntity(EntityType<? extends RedPearlEntity> type, Level level) {
        super(type, level);
    }

    public void setTargetEntity(LivingEntity target) {
        this.targetId = target.getId();
    }

    @Override
    protected Item getDefaultItem() {
        return Items.ENDER_PEARL;
    }

    @Override
    public void tick() {
        super.tick();

        if (this.level() instanceof ServerLevel serverLevel) {
            // --- Trajectoire courbe : on infléchit progressivement la vitesse vers la cible ---
            if (targetId != -1) {
                Entity target = serverLevel.getEntity(targetId);
                if (target instanceof LivingEntity living && living.isAlive()) {
                    Vec3 toTarget = living.getBoundingBox().getCenter()
                            .subtract(this.position())
                            .normalize();
                    Vec3 currentDir = this.getDeltaMovement().normalize();
                    double speed = Math.max(this.getDeltaMovement().length(), 0.55);

                    // Mélange direction actuelle / direction cible -> effet de courbe fluide, pas un tir laser
                    Vec3 curvedDir = currentDir.scale(0.72).add(toTarget.scale(0.38)).normalize();
                    this.setDeltaMovement(curvedDir.scale(speed));
                } else {
                    targetId = -1;
                }
            }

            // --- Traînée de particules rouges en 3D ---
            serverLevel.sendParticles(
                    new DustParticleOptions(new Vector3f(TRAIL_COLOR_R, TRAIL_COLOR_G, TRAIL_COLOR_B), 1.4f),
                    this.getX(), this.getY(), this.getZ(),
                    3, 0.02, 0.02, 0.02, 0.0
            );
        }

        // Sécurité : la perle se détruit après 6 secondes si elle ne touche rien
        if (this.tickCount > 120) {
            this.discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);

        if (!(this.level() instanceof ServerLevel serverLevel)) return;
        if (!(result.getEntity() instanceof LivingEntity victim)) return;
        if (!(this.getOwner() instanceof ServerPlayer player)) return;

        possess(serverLevel, player, victim);
        this.discard();
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (result.getType() != HitResult.Type.ENTITY && this.level() instanceof ServerLevel) {
            this.discard();
        }
    }

    private void possess(ServerLevel serverLevel, ServerPlayer player, LivingEntity victim) {
        PossessionState victimState = victim.getData(ModAttachments.POSSESSION.get());
        victimState.possessedBy = player.getUUID();

        PlayerPossessionState playerState = player.getData(ModAttachments.PLAYER_STATE.get());
        playerState.targetEntityId = victim.getId();

        // La caméra du joueur "devient" le corps de la victime
        player.setCamera(victim);
        player.displayClientMessage(
                Component.literal("Vous possédez " + victim.getDisplayName().getString()
                        + " ! Maintenez R pour la contrôler."),
                true
        );

        serverLevel.sendParticles(
                new DustParticleOptions(new Vector3f(1.0f, 0f, 0f), 2.2f),
                victim.getX(), victim.getY() + victim.getBbHeight() / 2.0, victim.getZ(),
                50, 0.3, 0.5, 0.3, 0.01
        );
    }
}
