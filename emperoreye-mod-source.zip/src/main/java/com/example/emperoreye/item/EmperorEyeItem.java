package com.example.emperoreye.item;

import com.example.emperoreye.entity.RedPearlEntity;
import com.example.emperoreye.registry.ModEntities;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Optional;

public class EmperorEyeItem extends Item {

    private static final double RANGE = 48.0;

    public EmperorEyeItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.pass(stack);
        }

        if (!level.isClientSide) {
            LivingEntity target = findTargetEntity(player);

            if (target != null) {
                RedPearlEntity pearl = new RedPearlEntity(ModEntities.RED_PEARL.get(), level);
                pearl.setOwner(player);
                pearl.setPos(player.getX(), player.getEyeY() - 0.1, player.getZ());
                pearl.setTargetEntity(target);

                Vec3 look = player.getLookAngle();
                pearl.setDeltaMovement(look.scale(0.7));
                pearl.setNoGravity(true);

                level.addFreshEntity(pearl);
                level.playSound(null, player.blockPosition(), SoundEvents.ENDER_EYE_LAUNCH, SoundSource.PLAYERS, 1.0f, 0.7f);
            } else {
                player.displayClientMessage(Component.literal("Aucune cible dans le viseur."), true);
            }
        }

        player.getCooldowns().addCooldown(this, 20);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /**
     * Fait un raytrace entité le long du regard du joueur (crosshair) sur RANGE blocs.
     */
    private LivingEntity findTargetEntity(Player player) {
        Vec3 eyePos = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 reach = eyePos.add(look.scale(RANGE));

        AABB searchBox = player.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(2.0);
        List<Entity> candidates = player.level().getEntities(player, searchBox);

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;

        for (Entity e : candidates) {
            if (!(e instanceof LivingEntity living) || !living.isAlive()) continue;

            AABB box = living.getBoundingBox().inflate(0.35);
            Optional<Vec3> hit = box.clip(eyePos, reach);
            if (hit.isPresent()) {
                double dist = eyePos.distanceToSqr(hit.get());
                if (dist < bestDist) {
                    bestDist = dist;
                    best = living;
                }
            }
        }
        return best;
    }
}
