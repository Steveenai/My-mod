package com.example.emperoreye.network;

import com.example.emperoreye.EmperorEyeMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record ControlVictimPayload(float forward, float strafe, boolean jump, boolean attack, boolean use)
        implements CustomPacketPayload {

    public static final Type<ControlVictimPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(EmperorEyeMod.MODID, "control_victim"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ControlVictimPayload> STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.FLOAT, ControlVictimPayload::forward,
                    ByteBufCodecs.FLOAT, ControlVictimPayload::strafe,
                    ByteBufCodecs.BOOL, ControlVictimPayload::jump,
                    ByteBufCodecs.BOOL, ControlVictimPayload::attack,
                    ByteBufCodecs.BOOL, ControlVictimPayload::use,
                    ControlVictimPayload::new
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
