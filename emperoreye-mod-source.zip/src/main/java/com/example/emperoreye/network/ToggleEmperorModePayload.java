package com.example.emperoreye.network;

import com.example.emperoreye.EmperorEyeMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record ToggleEmperorModePayload() implements CustomPacketPayload {
    public static final Type<ToggleEmperorModePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(EmperorEyeMod.MODID, "toggle_emperor"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ToggleEmperorModePayload> STREAM_CODEC =
            StreamCodec.unit(new ToggleEmperorModePayload());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
