package com.example.emperoreye.registry;

import com.example.emperoreye.EmperorEyeMod;
import com.example.emperoreye.util.PlayerPossessionState;
import com.example.emperoreye.util.PossessionState;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

public class ModAttachments {
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.Keys.ATTACHMENT_TYPES, EmperorEyeMod.MODID);

    // Sur la victime : par qui elle est possédée
    public static final DeferredHolder<AttachmentType<?>, AttachmentType<PossessionState>> POSSESSION =
            ATTACHMENT_TYPES.register("possession", () -> AttachmentType.builder(PossessionState::new).build());

    // Sur le joueur : son mode empereur + qui il possède
    public static final DeferredHolder<AttachmentType<?>, AttachmentType<PlayerPossessionState>> PLAYER_STATE =
            ATTACHMENT_TYPES.register("player_state", () -> AttachmentType.builder(PlayerPossessionState::new).build());
}
