package com.example.emperoreye.registry;

import com.example.emperoreye.EmperorEyeMod;
import com.example.emperoreye.entity.RedPearlEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, EmperorEyeMod.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<RedPearlEntity>> RED_PEARL =
            ENTITIES.register("red_pearl", () -> EntityType.Builder.<RedPearlEntity>of(RedPearlEntity::new, MobCategory.MISC)
                    .sized(0.25f, 0.25f)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build("red_pearl"));
}
