package com.example.emperoreye.registry;

import com.example.emperoreye.EmperorEyeMod;
import com.example.emperoreye.item.EmperorEyeItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(EmperorEyeMod.MODID);

    public static final DeferredHolder<Item, EmperorEyeItem> EMPEROR_EYE = ITEMS.registerItem(
            "emperor_eye",
            EmperorEyeItem::new,
            new Item.Properties().stacksTo(1).rarity(net.minecraft.world.item.Rarity.EPIC)
    );
}
