package com.example.emperoreye.registry;

import com.example.emperoreye.EmperorEyeMod;
import com.example.emperoreye.network.ControlVictimPayload;
import com.example.emperoreye.network.ToggleEmperorModePayload;
import com.example.emperoreye.server.ServerPayloadHandler;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public class ModPayloads {
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(EmperorEyeMod.MODID).versioned("1.0");

        registrar.playToServer(
                ToggleEmperorModePayload.TYPE,
                ToggleEmperorModePayload.STREAM_CODEC,
                ServerPayloadHandler::handleToggle
        );

        registrar.playToServer(
                ControlVictimPayload.TYPE,
                ControlVictimPayload.STREAM_CODEC,
                ServerPayloadHandler::handleControl
        );
    }
}
