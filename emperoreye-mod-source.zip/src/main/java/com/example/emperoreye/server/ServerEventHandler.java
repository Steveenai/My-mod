package com.example.emperoreye.server;

import com.example.emperoreye.registry.ModAttachments;
import com.example.emperoreye.util.PlayerPossessionState;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import org.joml.Vector3f;

public class ServerEventHandler {

    @SubscribeEvent
    public void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!(player.level() instanceof ServerLevel serverLevel)) return;

        PlayerPossessionState state = player.getData(ModAttachments.PLAYER_STATE.get());

        // Effet visuel rouge autour des "yeux" du joueur en mode empereur
        if (state.emperorMode) {
            serverLevel.sendParticles(
                    new DustParticleOptions(new Vector3f(1f, 0f, 0f), 1.0f),
                    player.getX(), player.getEyeY(), player.getZ(),
                    2, 0.15, 0.05, 0.15, 0.0
            );
        }

        // Gel de l'IA vanilla de la victime pendant la possession (sinon elle continue à agir seule)
        if (state.targetEntityId != -1) {
            Entity target = serverLevel.getEntity(state.targetEntityId);

            if (target instanceof LivingEntity victim && victim.isAlive()) {
                if (victim instanceof Mob mob) {
                    mob.getNavigation().stop();
                    mob.setTarget(null);
                }
            } else {
                // La victime est morte ou a disparu -> fin de la possession
                player.setCamera(player);
                state.targetEntityId = -1;
            }
        }
    }
}
