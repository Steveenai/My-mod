package com.example.emperoreye.server;

import com.example.emperoreye.network.ControlVictimPayload;
import com.example.emperoreye.network.ToggleEmperorModePayload;
import com.example.emperoreye.registry.ModAttachments;
import com.example.emperoreye.util.PlayerPossessionState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public class ServerPayloadHandler {

    public static void handleToggle(ToggleEmperorModePayload payload, IPayloadContext context) {
        context.player().getData(ModAttachments.PLAYER_STATE.get()).emperorMode ^= true;
    }

    public static void handleControl(ControlVictimPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;

        PlayerPossessionState state = player.getData(ModAttachments.PLAYER_STATE.get());
        if (state.targetEntityId == -1) return;
        if (!(player.level() instanceof ServerLevel serverLevel)) return;

        Entity target = serverLevel.getEntity(state.targetEntityId);
        if (!(target instanceof LivingEntity victim) || !victim.isAlive()) return;

        // Regard de la victime calqué sur celui du joueur
        victim.setYRot(player.getYRot());
        victim.setXRot(player.getXRot());
        victim.yHeadRot = player.getYRot();
        victim.yBodyRot = player.getYRot();

        // Déplacement
        Vec3 move = new Vec3(payload.strafe(), 0, payload.forward());
        if (move.lengthSqr() > 0) {
            victim.travel(move.scale(0.4));
        }

        // Saut
        if (payload.jump() && victim.onGround()) {
            victim.setDeltaMovement(victim.getDeltaMovement().add(0, 0.42, 0));
        }

        // Attaque : la victime frappe la première entité vivante devant elle
        if (payload.attack()) {
            for (Entity e : serverLevel.getEntities(victim, victim.getBoundingBox().inflate(2.5))) {
                if (e != victim && e instanceof LivingEntity l && l.isAlive()) {
                    victim.doHurtTarget(l);
                    break;
                }
            }
        }
    }
}
