package com.example.emperoreye.util;

/**
 * Attaché au joueur : son mode empereur (Z) et l'ID de l'entité qu'il possède (ou -1).
 */
public class PlayerPossessionState {
    public int targetEntityId = -1;
    public boolean emperorMode = false;
}
