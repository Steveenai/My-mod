package com.example.emperoreye.util;

import java.util.UUID;

/**
 * Attaché à une entité "victime" : qui la possède actuellement (ou null).
 */
public class PossessionState {
    public UUID possessedBy = null;
}
